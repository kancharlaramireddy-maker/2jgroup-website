import {requireChatGPTUser} from '../chatgpt-auth';
import {role} from '@/lib/commerce';
import Admin from './panel';
export const dynamic='force-dynamic';
export default async function Office(){await requireChatGPTUser('/admin');let u=null;try{u=await role();}catch{}if(!u||!['owner','office'].includes(u.role))return <main className="access"><h1>Office access required</h1><p>Only approved office staff can open this page.</p><a href="/sales">Sales portal</a></main>;return <Admin owner={u.role==='owner'}/>;}
